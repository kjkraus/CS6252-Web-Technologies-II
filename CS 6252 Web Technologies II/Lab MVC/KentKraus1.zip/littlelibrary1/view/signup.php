<?php
include 'shared/head.html';
include 'shared/header.html';
include 'shared/nav.html';
?>

<main>
	<h2>Sign up for our Newsletter</h2>
	<form method="post" id="signupform" action="index.php">
		<input type="hidden" id="idHidden" name="action" value="process_signup_form">
		<label for="idEmail">* E-mail: </label>
		<input type="email" id="idEmail" name="email" required="required">
		<input type="submit" value="Sign up" id="idSignup">
	</form>	
</main>

<?php
include 'shared/footer.html';
?>