<?php
include 'shared/head.html';
include 'shared/header.html';
include 'shared/nav.html';
?>

<main>
	<h2>Login</h2>
	Work in progress...
</main>

<?php
include 'shared/footer.html';
?>