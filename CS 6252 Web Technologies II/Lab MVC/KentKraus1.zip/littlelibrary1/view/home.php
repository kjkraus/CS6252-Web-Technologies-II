<?php
include 'shared/head.html';
include 'shared/header.html';
include 'shared/nav.html';
?>

<main>
	<h2>Welcome to the Little Library</h2>
	<img src="view/images/aLibrary.jpg" alt="image of empty library" width="216" height="240">
</main>

<?php
include 'shared/footer.html';
?>