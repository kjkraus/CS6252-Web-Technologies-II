<?php
include 'shared/head.html';
include 'shared/header.html';
include 'shared/nav.html';
?>

<main>
	<h2>Sorry, an error has occurred.</h2>
</main>

<?php
include 'shared/footer.html';
?>