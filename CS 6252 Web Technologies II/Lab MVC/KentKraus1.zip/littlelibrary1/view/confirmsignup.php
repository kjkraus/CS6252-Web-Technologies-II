<?php
include 'shared/head.html';
include 'shared/header.html';
include 'shared/nav.html';
?>

<main>
	<h2>Thank you for signing up for our newsletter!</h2>
	<p>We will send the newsletter to  <?php echo $email;?></p>

	<form method="post" action="index.php">
		<input type="hidden" name="action" value="show_signup_page" id="idBack">
		<input type="submit" value="Back" id="idBack">
	</form>
</main>

<?php
include 'shared/footer.html';
?>